package com.example.userservice.entity.enums;

/**
 * @author "Husniddin Ulachov"
 * @created 10:35 AM on 8/4/2022
 * @project AdminService
 */
public enum PayType {
    CASH,
    PAYME,
    CLICK

}
