package com.example.userservice.repository;

import com.example.userservice.entity.Favourite;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author "ISMOIL NIGMATOV"
 * @created 6:12 PM on 8/13/2022
 * @project fast-food
 */
public interface FavouriteRepository extends JpaRepository<Favourite,Long> {
    Page<Favourite> findAllByUser_Id(Long userId, Pageable pageable);
}
