package com.example.userservice.entity.enums;

/**
 * @author "Husniddin Ulachov"
 * @created 12:14 PM on 8/3/2022
 * @project adminService
 */
public enum OrderType {
   DELIVERY,
   SELF
}
