package com.example.userservice.entity.enums;

/**
 * @author "Husniddin Ulachov"
 * @created 10:36 AM on 8/4/2022
 * @project AdminService
 */
public enum SupportType {
    COMPLAINT,
    OFFER
}
