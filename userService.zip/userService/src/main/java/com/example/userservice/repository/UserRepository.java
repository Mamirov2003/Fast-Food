package com.example.userservice.repository;

import com.example.userservice.entity.Role;
import com.example.userservice.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * @author "ISMOIL NIGMATOV"
 * @created 11:25 PM on 8/10/2022
 * @project fast-food
 */
public interface UserRepository extends JpaRepository<User,Long> {
    Page<User> findAllByRole_NameContainingIgnoreCaseAndOnline(String role, Boolean online, Pageable pageable);
}
